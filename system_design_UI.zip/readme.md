# eTax Design System

Design system for **eTax**, an AI-assisted tax platform for a revenue authority. The product is a secure assistant used by authorized staff and taxpayers to ask questions about tax records, request fraud-risk predictions, and interact by text or voice. Access is gated by account credentials plus live face verification.

## Sources this system was built from

- `uploads/etax logo.png` — the supplied eTax logo (red shield with the lowercase "e", navy "tax" wordmark with a red accent under the "x"). The entire colour identity is derived from this file by sampling: red `#E22726`, navy `#193768`, background light gray `#E8ECF3`. Copied to `assets/etax-logo-original.png`; a background-removed version is at `assets/etax-logo.png`.
- `uploads/chatbot ui example design.png` — a generic pastel/gradient AI chat screen supplied as loose inspiration. Only its *layout* ideas were used (centred empty state, suggestion row above the composer, single composer with a trailing send control). Its pastel gradients, sparkle mark and pill shapes were deliberately **not** carried over; they conflict with the brief's government/financial requirements.
- No codebase, Figma file, brand guideline document or font binaries were provided. Everything below is an original system built around the logo's identity, and the type choices are documented substitutions (see Typography).

The product flow this system serves: **Landing → Sign up / Log in → Face verification → Assistant (chat)**, with a prediction dialog, prediction result, data-query answer state, voice-listening state, and authentication/verification error states.

## Index

| Path | What it is |
| --- | --- |
| `styles.css` | Global entry point — `@import` list only |
| `tokens/` | `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `elevation.css`, `motion.css`, `base.css` |
| `assets/` | `etax-logo.png` (transparent), `etax-logo-original.png` (as supplied) |
| `components/` | React primitives, grouped by concern (see below) |
| `ui_kits/tax_assistant/` | Click-through recreation of the whole product flow + its own README |
| `guidelines/` | Foundation specimen cards (colour, type, spacing, brand) |
| `thumbnail.html` | Homepage tile |
| `SKILL.md` | Agent-skill entry point |

## Components

Grouped by concern. Each directory holds `<Name>.jsx`, `<Name>.d.ts`, `<Name>.prompt.md`, and one `@dsCard` HTML.

- `components/core/` — **Button**, **IconButton**, **Icon**, **Card**, **Badge**, **Logo**
- `components/forms/` — **TextField**, **Select**, **Checkbox**
- `components/feedback/` — **Alert**, **StatusSteps**, **Spinner**
- `components/chat/` — **ChatMessage**, **ChatComposer**, **SuggestionChip**
- `components/data/** — **DataTable**
- `components/navigation/` — **AppHeader**
- `components/overlay/` — **Modal**

No source defined a component inventory, so this is an authored set sized to the product. Deliberate omissions: no Toast (messages stay inline as `Alert`), no Switch (binary settings use `Checkbox`), no Tabs, no Avatar component (initials are rendered inside `AppHeader`), no Tooltip. Add them only if a real screen needs them.

## Content fundamentals

The voice is that of a revenue authority's service desk: plain, specific, and never promotional.

- **Person.** Address the user as "you". The product refers to itself as "eTax" or "the assistant", never "I" in marketing copy; inside the conversation the assistant answers in plain statements without self-reference ("Your assessed income for 2024 was …", not "I found that …").
- **Casing.** Sentence case everywhere — headings, buttons, labels, table headers are the one exception (uppercase 11px overline). Never Title Case buttons.
- **Tone examples.** Landing: "eTax answers questions about taxpayer records you are cleared to access and runs the fraud risk model on request." Verification: "Position your face inside the frame." Status: "Retrieving authorized tax data…" Error: "We could not confirm your identity. Move closer, remove eyewear if possible, and try again."
- **Errors** name what happened, then what to do. They never blame the user and never expose internals. Say "The username or password is incorrect. Two attempts remain." — not "Auth 401".
- **No technical leakage.** Never show SQL, table or column names, model names, agent steps, endpoints, or confidence internals. The user sees "Retrieving authorized tax data…", then the answer.
- **Numbers** are written out with two decimals and thousands separators (`412,900.00`), set in mono. Risk scores use two decimals on a stated 0.00–1.00 range with the review threshold named.
- **Hedging where it matters.** Predictions always carry a limitation line: "A score above the review threshold does not confirm fraud."
- **No emoji, no exclamation marks, no "AI-powered", no "magic", no "seamless", no marketing adjectives.** Avoid "simply", "just", and "please" except where genuinely instructional ("Please blink once.").
- **Length.** One idea per sentence; body paragraphs under 3 lines. Buttons are 1–4 words and verb-first ("Log in", "Run prediction", "Try again").

## Visual foundations

**Colour.** Two brand colours and a navy-tinted gray ramp. Navy `#193768` carries structure and all default actions; eTax red `#E22726` is an accent with a strict budget — one red action per screen, the 3px top rule on a screen's lead panel, and live-capture states (recording, listening, liveness ring). Red is never used for body text, large fills, or two buttons in one view. Page canvas is `--gray-50` (`#F4F6F9`) and content sits on white; pure white is never the page background. Status colours are muted and institutional (green `#1C7A4A`, amber `#A86A00`, red `#C11F1E`) each paired with a 100-level tint background.

**Typography.** Three families, all Google Fonts substitutions since no vendor binaries were supplied: **Archivo** for display/headings (compact grotesque, closest match to the logo's "tax" letterforms), **Public Sans** for body and UI, **IBM Plex Mono** for amounts, references, TINs and timestamps. Headings are semibold with −1% to −2% tracking; body is 15px/1.55; the overline style is 11px uppercase with 9% tracking. Minimum text size in product UI is 12px, and only for captions.

**Layout.** Fixed 64–72px white header with a 1px bottom border; content in centred containers (440px auth, 820px conversation, 1080px marketing). 4px spacing base, used at 4/8/12/16/20/24/32/48/64. Generous vertical rhythm, no dense dashboard grids, and never more than two side-by-side panels. The chat shell is the only screen with a fixed footer (the composer).

**Backgrounds.** Flat colour only. No photography, no illustration, no patterns, no texture, no gradients — the single exception is the camera preview, which is a deep navy `#0F2545` field standing in for the live video stream. No hero imagery is included because none was supplied.

**Borders, radii, shadows.** 1px `--border-subtle` is the default divider; 2px only for the focus outline; 3px only for the red lead-panel rule. Radii are 2px (badges), 4px (controls, inputs, buttons, chips), 6px (cards, modals, camera frame). Nothing is pill-shaped except the small circular step markers. Shadows are near-flat: `--shadow-sm` on cards and the composer, `--shadow-modal` (0 20px 48px navy at 18%) on dialogs. No inner shadows, no glows, no coloured shadows.

**Cards** are white, 1px `--border-subtle`, 6px radius, `--shadow-sm`, 24px padding, with an optional 1px-bordered header row. Cards never nest, and never carry a coloured left border.

**States.** Hover darkens navy fills one step (`--action-primary-hover`) and tints neutral surfaces to `--gray-50`/`--etax-navy-50`; secondary buttons darken their border rather than their fill. Press states reuse the darkest step (`--action-primary-active`) — nothing scales or shrinks. Focus is a 1px navy border plus a 3px navy 28% ring (`--focus-ring`). Disabled is 45% opacity with `not-allowed`. Selected/active navigation is marked by a 2px red underline, not a filled tab.

**Motion.** Functional only: 120ms for hover/focus/colour, 200ms for panel and modal entry (fade plus 4px rise), 320ms for screen changes, all on `cubic-bezier(.2,0,.2,1)`. The only looping animations are the 1600ms opacity pulse on live-capture indicators and the listening waveform bars. No bounce, no spring, no parallax, no skeleton shimmer; everything is disabled under `prefers-reduced-motion`.

**Transparency and blur.** Almost none. The modal scrim is navy at 42%; the camera overlay chip is navy at 72%. No backdrop blur, no frosted panels anywhere.

**Imagery vibe.** If photography is ever added it should be cool-toned, neutral, documentary — no warm filters, no grain, no stock-office optimism. None ships with this system.

## Iconography

- **Set:** [Lucide](https://lucide.dev) at pinned version `0.462.0`, loaded from `unpkg.com/lucide@0.462.0/dist/umd/lucide.min.js` on every page (add the script tag before `_ds_bundle.js`). This is a **flagged substitution** — no icon set was supplied with the brand. Lucide was chosen for its 2px uniform stroke, rounded caps and neutral, non-decorative shapes, which suit a civic product.
- **How to use it:** always through the `Icon` component, which renders the Lucide node inline so the glyph inherits `currentColor`. Never paste inline SVG paths, never use PNG icons, never use emoji or Unicode symbols (`✓`, `→`) as icons.
- **Sizes:** 13–14px inline with small text, 16px in small buttons and labels, 18px in standard buttons and alerts, 20–22px in headers and feature rows.
- **Colour:** navy for structural/informational icons, gray-500 for inert affordances (chevrons, reveal eye), red only in live-capture and single-accent contexts, status colour inside alerts.
- **Glyphs in use:** `mic`, `square` (stop), `send`, `volume-2`, `pause`, `user`, `landmark` (assistant avatar), `log-out`, `lock`, `shield-check`, `shield-alert`, `scan-face`, `eye` / `eye-off`, `check`, `x`, `circle-alert`, `circle-check`, `triangle-alert`, `info`, `chevron-down`, `database`, `calculator`, `messages-square`, `download`.
- **Forbidden:** sparkles, wands, robots, brains, or any "AI" decoration.

## Intentional additions

- **Icon** — a wrapper over the substituted Lucide set, so consumers never hand-roll SVG.
- **StatusSteps** — the face-verification flow needs a stage checklist and no equivalent existed in the brief.
- **DataTable** — query answers must render records; the brief describes the answer but supplies no component.

## Open substitutions to confirm

1. Fonts: Archivo / Public Sans / IBM Plex Mono stand in for the unknown brand typeface. Send the real font files and the specimen cards and tokens can be repointed in one pass.
2. Icons: Lucide stands in for an unknown icon set.
3. The logo was background-removed programmatically from the supplied PNG. A vector (SVG/EPS) original would give crisper rendering at small sizes and allow a proper white knockout instead of a CSS filter.
