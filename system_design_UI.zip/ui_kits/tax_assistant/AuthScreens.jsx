const { Button, Logo, Icon, TextField, Checkbox, Alert } = window.ETaxDesignSystem_2776b3;

function AuthShell({ title, description, children, footer }) {
  return (
    <div style={{ minHeight: '100%', background: 'var(--surface-page)', display: 'flex', flexDirection: 'column' }}>
      <header style={{ display: 'flex', alignItems: 'center', height: 72, padding: '0 var(--space-8)', background: 'var(--white)', borderBottom: '1px solid var(--border-subtle)' }}>
        <Logo height={30} src={window.LOGO} subtitle="Tax Assistant" />
      </header>
      <main style={{ flex: 1, display: 'flex', justifyContent: 'center', padding: 'var(--space-12) var(--space-4)' }}>
        <div style={{ width: '100%', maxWidth: 480 }}>
          <div style={{ background: 'var(--white)', border: '1px solid var(--border-subtle)', borderTop: '3px solid var(--action-accent)', borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-sm)', padding: 'var(--space-8)' }}>
            <h1 style={{ fontSize: 'var(--text-h1)', marginBottom: 'var(--space-2)' }}>{title}</h1>
            <p style={{ fontSize: 'var(--text-body-sm)', color: 'var(--text-muted)', marginBottom: 'var(--space-6)' }}>{description}</p>
            {children}
          </div>
          <p style={{ textAlign: 'center', marginTop: 'var(--space-5)', fontSize: 'var(--text-body-sm)', color: 'var(--text-muted)' }}>{footer}</p>
        </div>
      </main>
    </div>
  );
}

function SignUpScreen({ onSubmit, onLogin }) {
  const [err, setErr] = React.useState('');
  const submit = (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    if (f.get('password') !== f.get('confirm')) { setErr('Passwords do not match'); return; }
    onSubmit(f.get('name') || 'Amina Farouk');
  };
  return (
    <AuthShell title="Create your account" description="You will enrol your face on the next step. It is used only to confirm it is you at sign-in."
      footer={<>Already registered? <a href="#" onClick={(e) => { e.preventDefault(); onLogin(); }}>Log in</a></>}>
      <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
        <TextField label="Full name" name="name" required placeholder="As shown on your tax ID" defaultValue="Amina Farouk" />
        <TextField label="Email address" name="email" type="email" required defaultValue="a.farouk@revenue.gov" hint="Used for security notices and account recovery" />
        <TextField label="Username" name="username" required defaultValue="afarouk" />
        <TextField label="Password" name="password" type="password" revealable required defaultValue="StrongPass2026" hint="At least 12 characters, including a number" />
        <TextField label="Confirm password" name="confirm" type="password" revealable required defaultValue="StrongPass2026" error={err || undefined} />
        <Checkbox defaultChecked label={<>I agree to the <a href="#">terms of use</a> and the <a href="#">privacy notice</a>.</>} />
        <Button type="submit" size="lg" fullWidth>Create account and continue</Button>
      </form>
    </AuthShell>
  );
}

function LoginScreen({ onSubmit, onSignUp, initialError }) {
  const [error, setError] = React.useState(initialError || '');
  const [pw, setPw] = React.useState('StrongPass2026');
  const submit = (e) => {
    e.preventDefault();
    if (pw.length < 6) { setError('The username or password is incorrect. Two attempts remain.'); return; }
    onSubmit('Amina Farouk');
  };
  return (
    <AuthShell title="Log in" description="Face verification follows once your credentials are accepted."
      footer={<>No account yet? <a href="#" onClick={(e) => { e.preventDefault(); onSignUp(); }}>Create one</a></>}>
      <form onSubmit={submit} style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
        {error && <Alert tone="danger" title="Sign-in failed">{error}</Alert>}
        <TextField label="Email or username" required defaultValue="afarouk" error={error ? ' ' : undefined} />
        <TextField label="Password" type="password" revealable required value={pw} onChange={(e) => setPw(e.target.value)} error={error ? ' ' : undefined} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Checkbox label="Remember this device" />
          <a href="#" style={{ fontSize: 'var(--text-body-sm)' }}>Forgot password?</a>
        </div>
        <Button type="submit" size="lg" fullWidth>Log in</Button>
        <p style={{ fontSize: 'var(--text-caption)', color: 'var(--text-muted)', display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
          <Icon name="lock" size={13} /> Do not share your credentials. eTax staff will never ask for your password.
        </p>
      </form>
    </AuthShell>
  );
}

Object.assign(window, { AuthShell, SignUpScreen, LoginScreen });
