function App() {
  const [screen, setScreen] = React.useState('landing');
  const [user, setUser] = React.useState('Amina Farouk');
  const go = (s) => setScreen(s);
  return (
    <div style={{ height: '100vh', overflow: screen === 'chat' ? 'hidden' : 'auto' }}>
      {screen === 'landing' && <window.LandingScreen onLogin={() => go('login')} onSignUp={() => go('signup')} />}
      {screen === 'signup' && <window.SignUpScreen onLogin={() => go('login')} onSubmit={(n) => { setUser(n); go('verify'); }} />}
      {screen === 'login' && <window.LoginScreen onSignUp={() => go('signup')} onSubmit={(n) => { setUser(n); go('verify'); }} />}
      {screen === 'verify' && <window.FaceVerifyScreen user={user} onVerified={() => go('chat')} onCancel={() => go('login')} />}
      {screen === 'chat' && <window.ChatScreen user={user} onSignOut={() => go('landing')} />}
    </div>
  );
}
ReactDOM.createRoot(document.getElementById('root')).render(<App />);
