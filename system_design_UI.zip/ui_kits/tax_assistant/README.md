# UI kit — eTax Tax Assistant

Click-through recreation of the full product flow. Open `index.html`.

**Flow:** Landing → Create account / Log in → Face verification (auto-advances through camera → face detected → liveness → identity, ~6s) → Assistant.

**Screens and states**

| File | Covers |
| --- | --- |
| `LandingScreen.jsx` | Landing page, header, capability rows, footer |
| `AuthScreens.jsx` | `AuthShell`, sign up (with confirm-password mismatch error), log in (with sign-in failure alert, forgot password, link to sign up) |
| `FaceVerifyScreen.jsx` | Camera frame, four verification stages, verified state, failed state ("Simulate a failed check") |
| `ChatScreen.jsx` | Empty state with suggestions, user/assistant turns, "Retrieving authorized tax data…" status, data-query answer with records table, prediction result, voice-listening state, session error state, read-aloud control |
| `PredictionModal.jsx` | Prediction input dialog (placeholder model variables) |
| `App.jsx` | Screen state machine |

**Things to try:** click a suggestion (query answer), press the microphone (listening state → answer), press "Tax prediction" or ask anything containing "predict"/"risk" (modal → result), "Show error state", "Simulate a failed check", the speaker control on any assistant answer.

All primitives come from the design system bundle (`window.ETaxDesignSystem_2776b3`); nothing is re-implemented here. Data, names and amounts are fictional placeholders. The camera area is a placeholder field, not a real video stream, and the prediction fields are labelled "Model input 1…4" pending the real trained-model variables.
