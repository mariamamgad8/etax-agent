const { AppHeader, ChatMessage, ChatComposer, SuggestionChip, Spinner, DataTable, Card, Badge, Button, Alert, Icon, IconButton } = window.ETaxDesignSystem_2776b3;

const SUGGESTIONS = [
  'Show the filed returns for TIN ending 4182',
  'What was the assessed income for the 2024 tax year?',
  'Run a fraud risk prediction for this taxpayer',
];

function PredictionResult() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
      <p>The model returned a moderate risk score for TIN ending 4182, 2024 tax year.</p>
      <div style={{ border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-sm)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-4)', padding: 'var(--space-4)', borderBottom: '1px solid var(--border-subtle)' }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: 30, fontWeight: 500, color: 'var(--etax-navy)' }}>0.58</span>
          <div>
            <Badge tone="warning">Moderate risk</Badge>
            <p style={{ fontSize: 'var(--text-caption)', color: 'var(--text-muted)', marginTop: 4 }}>Score range 0.00–1.00 · threshold for review 0.50</p>
          </div>
        </div>
        <div style={{ padding: 'var(--space-4)', display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
          {[['Model input 1', 'Above segment median'], ['Model input 2', 'Within expected range'], ['Model input 3', 'Two amendments in period']].map(([k, v]) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', gap: 'var(--space-4)', fontSize: 'var(--text-body-sm)' }}>
              <span style={{ color: 'var(--text-muted)' }}>{k}</span>
              <span style={{ color: 'var(--gray-800)' }}>{v}</span>
            </div>
          ))}
        </div>
      </div>
      <p style={{ fontSize: 'var(--text-body-sm)', color: 'var(--text-muted)' }}>A score above the review threshold does not confirm fraud. Refer the case for manual review before any action.</p>
    </div>
  );
}

function QueryAnswer() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-4)' }}>
      <p>Three returns are on file for TIN ending 4182. The 2022 return was amended in November 2023.</p>
      <DataTable caption="Authorized records · TIN ending 4182"
        columns={['Tax year', 'Return type', 'Status', { label: 'Assessed', numeric: true }, { label: 'Paid', numeric: true }]}
        rows={[['2024', 'Individual', 'Filed', '412,900.00', '412,900.00'], ['2023', 'Individual', 'Filed', '388,450.00', '388,450.00'], ['2022', 'Individual', 'Amended', '341,200.00', '330,000.00']]} />
    </div>
  );
}

function EmptyState({ onPick }) {
  return (
    <div style={{ maxWidth: 700, margin: '0 auto', paddingTop: 'var(--space-16)', textAlign: 'left' }}>
      <p className="etax-overline" style={{ marginBottom: 'var(--space-3)' }}>New conversation</p>
      <h1 style={{ fontSize: 'var(--text-h1)', marginBottom: 'var(--space-3)' }}>What would you like to look into?</h1>
      <p style={{ fontSize: 'var(--text-body-md)', color: 'var(--text-body)', marginBottom: 'var(--space-6)', maxWidth: 560 }}>
        Ask about records you are authorized to access, or request a fraud risk prediction. You can type or use the microphone.
      </p>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-2)' }}>
        {SUGGESTIONS.map((s) => <SuggestionChip key={s} onClick={() => onPick(s)}>{s}</SuggestionChip>)}
      </div>
    </div>
  );
}

function ChatScreen({ user, onSignOut }) {
  const [turns, setTurns] = React.useState([]);
  const [status, setStatus] = React.useState(null); // 'retrieving' | 'predicting'
  const [listening, setListening] = React.useState(false);
  const [modal, setModal] = React.useState(false);
  const [playing, setPlaying] = React.useState(null);
  const [error, setError] = React.useState('');
  const scroller = React.useRef(null);

  React.useEffect(() => { if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight; }, [turns, status]);

  const push = (t) => setTurns((prev) => prev.concat(t));

  const ask = (text) => {
    setError('');
    push({ role: 'user', body: text, time: '09:41' });
    const wantsPrediction = /predict|risk|fraud/i.test(text);
    if (wantsPrediction) { setTimeout(() => setModal(true), 350); return; }
    setStatus('retrieving');
    setTimeout(() => { setStatus(null); push({ role: 'assistant', kind: 'query', time: '09:41' }); }, 1600);
  };

  const runPrediction = () => {
    setModal(false); setStatus('predicting');
    setTimeout(() => { setStatus(null); push({ role: 'assistant', kind: 'prediction', time: '09:42' }); }, 1800);
  };

  const toggleMic = () => {
    if (listening) { setListening(false); ask('What was the assessed income for the 2024 tax year?'); return; }
    setListening(true);
    setTimeout(() => { setListening(false); ask('What was the assessed income for the 2024 tax year?'); }, 2600);
  };

  return (
    <div style={{ height: '100%', display: 'flex', flexDirection: 'column', background: 'var(--surface-page)' }}>
      <AppHeader logoSrc={window.LOGO} user={user} verified onSignOut={onSignOut}
        nav={<><a href="#" style={{ fontSize: 'var(--text-body-sm)', borderBottom: '2px solid var(--etax-red)', paddingBottom: 2, color: 'var(--text-strong)', fontWeight: 'var(--fw-semibold)' }}>Assistant</a><a href="#" style={{ fontSize: 'var(--text-body-sm)', border: 'none', color: 'var(--gray-600)' }}>Activity log</a></>} />
      <div ref={scroller} style={{ flex: 1, overflowY: 'auto', padding: 'var(--space-6) var(--space-8) var(--space-8)' }}>
        {turns.length === 0 && !status ? <EmptyState onPick={ask} /> : (
          <div style={{ maxWidth: 820, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 'var(--space-6)' }}>
            {turns.map((t, i) => (
              <ChatMessage key={i} role={t.role} time={t.time} speakable={t.role === 'assistant'} playing={playing === i} onPlay={() => setPlaying(playing === i ? null : i)}>
                {t.kind === 'query' ? <QueryAnswer /> : t.kind === 'prediction' ? <PredictionResult /> : t.body}
              </ChatMessage>
            ))}
            {status && (
              <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'center', paddingLeft: 44 }}>
                <Spinner label={status === 'retrieving' ? 'Retrieving authorized tax data…' : 'Running the prediction model…'} />
              </div>
            )}
          </div>
        )}
      </div>
      <div style={{ borderTop: '1px solid var(--border-subtle)', background: 'var(--white)', padding: 'var(--space-4) var(--space-8) var(--space-6)' }}>
        <div style={{ maxWidth: 820, margin: '0 auto', display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
          {error && <Alert tone="danger" title="Session expired">Your verified session has ended. Sign in and verify again to continue.</Alert>}
          {listening && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--space-3)', padding: 'var(--space-3) var(--space-4)', background: 'var(--etax-red-50)', border: '1px solid var(--etax-red-100)', borderRadius: 'var(--radius-sm)' }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--etax-red)', animation: 'etaxPulse var(--dur-pulse) var(--ease-in-out) infinite' }} />
              <span style={{ fontSize: 'var(--text-body-sm)', color: 'var(--etax-red-800)', fontWeight: 'var(--fw-medium)' }}>Listening — speak your question, then pause</span>
              <span style={{ marginLeft: 'auto', display: 'flex', gap: 3, alignItems: 'flex-end', height: 18 }}>
                {[7, 14, 10, 18, 9, 13, 6].map((h, i) => <span key={i} style={{ width: 3, height: h, background: 'var(--etax-red)', opacity: 0.8, animation: `etaxBar 900ms ${i * 90}ms var(--ease-in-out) infinite` }} />)}
              </span>
            </div>
          )}
          <ChatComposer listening={listening} onMicToggle={toggleMic} onSend={ask}
            hint="Answers cover records you are authorized to access. Every retrieval is logged against your session." />
          <div style={{ display: 'flex', gap: 'var(--space-4)', alignItems: 'center' }}>
            <Button variant="ghost" size="sm" onClick={() => setModal(true)}><Icon name="calculator" size={15} /> Tax prediction</Button>
            <Button variant="ghost" size="sm" onClick={() => setError('x')}><Icon name="circle-alert" size={15} /> Show error state</Button>
            <span style={{ marginLeft: 'auto', fontSize: 'var(--text-caption)', color: 'var(--text-muted)' }}>Session ends after 15 minutes of inactivity</span>
          </div>
        </div>
      </div>
      <window.PredictionModal open={modal} onClose={() => setModal(false)} onRun={runPrediction} />
      <style>{'@keyframes etaxBar{0%,100%{transform:scaleY(.4)}50%{transform:scaleY(1)}}@keyframes etaxPulse{0%,100%{opacity:1}50%{opacity:.25}}'}</style>
    </div>
  );
}

Object.assign(window, { ChatScreen, PredictionResult, QueryAnswer });
