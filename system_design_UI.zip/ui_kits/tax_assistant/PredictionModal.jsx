const { Modal, Button, TextField, Select, Alert } = window.ETaxDesignSystem_2776b3;

/** Prediction inputs. Field names are deliberate placeholders — swap in the trained model's variables. */
function PredictionModal({ open, onClose, onRun }) {
  return (
    <Modal open={open} onClose={onClose} width={640}
      title="Tax prediction inputs"
      description="Values are used for this prediction only and are not written to the taxpayer record."
      footer={<><Button variant="secondary" onClick={onClose}>Cancel</Button><Button onClick={onRun}>Run prediction</Button></>}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-5)' }}>
        <Alert tone="info" title="Placeholder inputs">Replace these five fields with the trained model's variables before release.</Alert>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 'var(--space-4) var(--space-5)' }}>
          <TextField label="Taxpayer reference" required defaultValue="TIN-•••• 4182" hint="Must be a record you are authorized to access" />
          <Select label="Assessment period" required options={['2024 tax year', '2023 tax year', '2022 tax year']} />
          <TextField label="Model input 1" placeholder="Numeric placeholder" required />
          <TextField label="Model input 2" placeholder="Numeric placeholder" required />
          <TextField label="Model input 3" placeholder="Numeric placeholder" />
          <Select label="Model input 4" options={['Category A', 'Category B', 'Category C']} />
        </div>
      </div>
    </Modal>
  );
}

Object.assign(window, { PredictionModal });
