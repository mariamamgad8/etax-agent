const { Button, Logo, Icon, StatusSteps, Alert, Badge } = window.ETaxDesignSystem_2776b3;

const STAGES = [
  { key: 'position', hint: 'Position your face inside the frame', steps: 0 },
  { key: 'detected', hint: 'Face detected — hold still', steps: 1 },
  { key: 'liveness', hint: 'Checking liveness. Please blink once.', steps: 2 },
  { key: 'identity', hint: 'Verifying identity against your enrolled record', steps: 3 },
  { key: 'verified', hint: 'Identity verified', steps: 4 },
];

function CameraFrame({ stage, failed }) {
  const live = !failed && stage !== 'verified';
  const ringColor = failed ? 'var(--danger)' : stage === 'verified' ? 'var(--success)' : stage === 'position' ? 'rgba(255,255,255,.55)' : 'var(--etax-red)';
  return (
    <div style={{ position: 'relative', aspectRatio: '4 / 3', background: 'var(--etax-navy-900)', borderRadius: 'var(--radius-md)', overflow: 'hidden', border: '1px solid var(--etax-navy-800)' }}>
      <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <div style={{ width: '46%', height: '72%', border: `2px ${stage === 'position' ? 'dashed' : 'solid'} ${ringColor}`, borderRadius: '50% / 42%', transition: 'border-color var(--dur-med) var(--ease-standard)' }} />
      </div>
      <span style={{ position: 'absolute', top: 12, left: 12, display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 8px', borderRadius: 'var(--radius-xs)', background: 'rgba(15,37,69,.72)', color: 'var(--white)', fontSize: 'var(--text-caption)', fontFamily: 'var(--font-mono)' }}>
        <span style={{ width: 7, height: 7, borderRadius: '50%', background: live ? 'var(--etax-red)' : 'var(--gray-400)', animation: live ? 'etaxPulse var(--dur-pulse) var(--ease-in-out) infinite' : 'none' }} />
        {live ? 'LIVE' : 'PAUSED'}
      </span>
      <span style={{ position: 'absolute', bottom: 12, left: 12, right: 12, textAlign: 'center', color: 'rgba(255,255,255,.62)', fontSize: 'var(--text-caption)' }}>
        Camera preview area — replace with the live video stream
      </span>
    </div>
  );
}

function FaceVerifyScreen({ user, onVerified, onCancel }) {
  const [i, setI] = React.useState(0);
  const [failed, setFailed] = React.useState(false);
  const [running, setRunning] = React.useState(true);
  React.useEffect(() => {
    if (!running || failed) return undefined;
    if (i >= STAGES.length - 1) { const t = setTimeout(onVerified, 1100); return () => clearTimeout(t); }
    const t = setTimeout(() => setI((n) => n + 1), i === 0 ? 1400 : 1700);
    return () => clearTimeout(t);
  }, [i, running, failed]);
  const stage = STAGES[i];
  const retry = () => { setFailed(false); setI(0); setRunning(true); };
  return (
    <div style={{ minHeight: '100%', background: 'var(--surface-page)', display: 'flex', flexDirection: 'column' }}>
      <header style={{ display: 'flex', alignItems: 'center', height: 72, padding: '0 var(--space-8)', background: 'var(--white)', borderBottom: '1px solid var(--border-subtle)' }}>
        <Logo height={30} src={window.LOGO} subtitle="Identity check" />
        <Badge tone="navy" style={{ marginLeft: 'auto' }}>Step 2 of 2</Badge>
      </header>
      <main style={{ flex: 1, display: 'flex', justifyContent: 'center', padding: 'var(--space-10) var(--space-4)' }}>
        <div style={{ width: '100%', maxWidth: 860 }}>
          <h1 style={{ fontSize: 'var(--text-h1)', marginBottom: 'var(--space-2)' }}>Verify your identity</h1>
          <p style={{ fontSize: 'var(--text-body-md)', color: 'var(--text-body)', marginBottom: 'var(--space-6)' }}>
            {user ? `${user}, ` : ''}look straight at the camera in even lighting. Nothing is recorded — the check runs and is discarded.
          </p>
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,1.4fr) minmax(0,1fr)', gap: 'var(--space-6)', background: 'var(--white)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-sm)', padding: 'var(--space-6)' }}>
            <CameraFrame stage={failed ? 'failed' : stage.key} failed={failed} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--space-5)' }}>
              <div>
                <p className="etax-overline" style={{ marginBottom: 'var(--space-3)' }}>Security check</p>
                <StatusSteps steps={['Camera ready', 'Face detected', 'Liveness check', 'Identity verified']} current={failed ? 2 : stage.steps} failed={failed} />
              </div>
              {failed ? (
                <Alert tone="danger" title="Verification failed">We could not confirm your identity. Move closer, remove eyewear if possible, and try again.</Alert>
              ) : stage.key === 'verified' ? (
                <Alert tone="success" title="Identity verified">Opening your assistant.</Alert>
              ) : (
                <div style={{ display: 'flex', gap: 'var(--space-3)', alignItems: 'flex-start', padding: 'var(--space-4)', background: 'var(--gray-50)', border: '1px solid var(--border-subtle)', borderRadius: 'var(--radius-sm)' }}>
                  <Icon name="scan-face" size={18} color="var(--etax-navy)" style={{ marginTop: 1 }} />
                  <p style={{ fontSize: 'var(--text-body-sm)', color: 'var(--gray-800)' }}>{stage.hint}</p>
                </div>
              )}
              <div style={{ marginTop: 'auto', display: 'flex', flexDirection: 'column', gap: 'var(--space-3)' }}>
                {failed ? <Button fullWidth onClick={retry}>Try again</Button> : null}
                {!failed && <Button variant="secondary" fullWidth onClick={() => { setFailed(true); setRunning(false); }}>Simulate a failed check</Button>}
                <Button variant="ghost" fullWidth onClick={onCancel}>Cancel and return to login</Button>
              </div>
            </div>
          </div>
          <p style={{ fontSize: 'var(--text-caption)', color: 'var(--text-muted)', marginTop: 'var(--space-4)', display: 'flex', gap: 'var(--space-2)', alignItems: 'center' }}>
            <Icon name="lock" size={13} /> Face data stays on the verification service and is never shown to other users.
          </p>
        </div>
      </main>
    </div>
  );
}

Object.assign(window, { FaceVerifyScreen, CameraFrame });
