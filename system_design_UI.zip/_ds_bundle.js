/* @ds-bundle: {"format":4,"namespace":"ETaxDesignSystem_2776b3","components":[{"name":"ChatComposer","sourcePath":"components/chat/ChatComposer.jsx"},{"name":"ChatMessage","sourcePath":"components/chat/ChatMessage.jsx"},{"name":"SuggestionChip","sourcePath":"components/chat/SuggestionChip.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"Logo","sourcePath":"components/core/Logo.jsx"},{"name":"DataTable","sourcePath":"components/data/DataTable.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Spinner","sourcePath":"components/feedback/Spinner.jsx"},{"name":"StatusSteps","sourcePath":"components/feedback/StatusSteps.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"AppHeader","sourcePath":"components/navigation/AppHeader.jsx"},{"name":"Modal","sourcePath":"components/overlay/Modal.jsx"}],"sourceHashes":{"components/chat/ChatComposer.jsx":"483a728eee36","components/chat/ChatMessage.jsx":"a7e64c926f7e","components/chat/SuggestionChip.jsx":"1e960b6965e4","components/core/Badge.jsx":"1531268e2718","components/core/Button.jsx":"0933c94cf65e","components/core/Card.jsx":"6ce5ae43791d","components/core/Icon.jsx":"33bf2b29c0db","components/core/IconButton.jsx":"2d3425db19ac","components/core/Logo.jsx":"ea38ec022c52","components/data/DataTable.jsx":"e045313f82d4","components/feedback/Alert.jsx":"ea993f38efe5","components/feedback/Spinner.jsx":"b8f9d5fdb09f","components/feedback/StatusSteps.jsx":"5a7bfac6e4a6","components/forms/Checkbox.jsx":"8d1fa522f688","components/forms/Select.jsx":"9b9d5e20e430","components/forms/TextField.jsx":"3ccfa5d50000","components/navigation/AppHeader.jsx":"c0606d11deb1","components/overlay/Modal.jsx":"f3f2dff4e320","ui_kits/tax_assistant/App.jsx":"7ddb14e6f4e4","ui_kits/tax_assistant/AuthScreens.jsx":"9748998929dd","ui_kits/tax_assistant/ChatScreen.jsx":"ca718f7475ff","ui_kits/tax_assistant/FaceVerifyScreen.jsx":"d0a6252e3016","ui_kits/tax_assistant/LandingScreen.jsx":"4518debecea2","ui_kits/tax_assistant/PredictionModal.jsx":"a22a8a8785e1"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.ETaxDesignSystem_2776b3 = window.ETaxDesignSystem_2776b3 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/chat/SuggestionChip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Suggested question the user can send with one click. */
function SuggestionChip({
  children,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick
  }, rest, {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      textAlign: 'left',
      padding: 'var(--space-3) var(--space-4)',
      cursor: 'pointer',
      background: hover ? 'var(--etax-navy-50)' : 'var(--white)',
      border: `1px solid ${hover ? 'var(--etax-navy-100)' : 'var(--border-subtle)'}`,
      borderRadius: 'var(--radius-sm)',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-strong)',
      transition: 'background-color var(--dur-fast) var(--ease-standard),border-color var(--dur-fast) var(--ease-standard)',
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { SuggestionChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chat/SuggestionChip.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  neutral: {
    background: 'var(--gray-100)',
    color: 'var(--gray-700)',
    border: 'var(--gray-200)'
  },
  navy: {
    background: 'var(--etax-navy-50)',
    color: 'var(--etax-navy)',
    border: 'var(--etax-navy-100)'
  },
  success: {
    background: 'var(--success-100)',
    color: 'var(--success)',
    border: '#bfe3ce'
  },
  warning: {
    background: 'var(--warning-100)',
    color: 'var(--warning)',
    border: '#f0d9a8'
  },
  danger: {
    background: 'var(--danger-100)',
    color: 'var(--danger)',
    border: '#f6c9c8'
  }
};

/** Small status label. Square-ish (2px radius) — pills are reserved for filter chips. */
function Badge({
  tone = 'neutral',
  children,
  style,
  ...rest
}) {
  const t = tones[tone];
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-1)',
      padding: '2px var(--space-2)',
      borderRadius: 'var(--radius-xs)',
      background: t.background,
      color: t.color,
      border: `1px solid ${t.border}`,
      fontSize: 'var(--text-caption)',
      fontWeight: 'var(--fw-semibold)',
      letterSpacing: '0.02em',
      whiteSpace: 'nowrap',
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const base = {
  display: 'inline-flex',
  alignItems: 'center',
  justifyContent: 'center',
  gap: 'var(--space-2)',
  fontFamily: 'var(--font-body)',
  fontWeight: 'var(--fw-semibold)',
  letterSpacing: '0.01em',
  border: '1px solid transparent',
  borderRadius: 'var(--radius-sm)',
  cursor: 'pointer',
  transition: 'background-color var(--dur-fast) var(--ease-standard),border-color var(--dur-fast) var(--ease-standard),color var(--dur-fast) var(--ease-standard)',
  textDecoration: 'none',
  whiteSpace: 'nowrap'
};
const sizes = {
  sm: {
    height: 'var(--control-h-sm)',
    padding: '0 var(--space-3)',
    fontSize: 'var(--text-body-sm)'
  },
  md: {
    height: 'var(--control-h-md)',
    padding: '0 var(--space-5)',
    fontSize: 'var(--text-body-md)'
  },
  lg: {
    height: 'var(--control-h-lg)',
    padding: '0 var(--space-6)',
    fontSize: 'var(--text-body-lg)'
  }
};
const variants = {
  primary: {
    background: 'var(--action-primary)',
    color: 'var(--text-inverse)'
  },
  accent: {
    background: 'var(--action-accent)',
    color: 'var(--text-inverse)'
  },
  secondary: {
    background: 'var(--white)',
    color: 'var(--etax-navy)',
    borderColor: 'var(--border-default)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--etax-navy-600)'
  },
  danger: {
    background: 'var(--white)',
    color: 'var(--danger)',
    borderColor: 'var(--danger)'
  }
};
const hovers = {
  primary: {
    background: 'var(--action-primary-hover)'
  },
  accent: {
    background: 'var(--action-accent-hover)'
  },
  secondary: {
    background: 'var(--gray-50)',
    borderColor: 'var(--border-strong)'
  },
  ghost: {
    background: 'var(--etax-navy-50)'
  },
  danger: {
    background: 'var(--danger-100)'
  }
};

/** Primary text action. Navy = default commit action, red = single highest-stakes action per screen. */
function Button({
  variant = 'primary',
  size = 'md',
  fullWidth,
  disabled,
  as = 'button',
  children,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({}, rest, {
    disabled: Tag === 'button' ? disabled : undefined,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      ...base,
      ...sizes[size],
      ...variants[variant],
      ...(hover && !disabled ? hovers[variant] : null),
      width: fullWidth ? '100%' : undefined,
      opacity: disabled ? 0.45 : 1,
      cursor: disabled ? 'not-allowed' : 'pointer',
      ...style
    }
  }), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Flat white panel: 1px gray border, 6px radius, optional navy header rule. */
function Card({
  title,
  action,
  padding = 'var(--space-6)',
  accentTop,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("section", _extends({}, rest, {
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderTop: accentTop ? '3px solid var(--action-accent)' : '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-sm)',
      ...style
    }
  }), title && /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      padding: `var(--space-4) ${padding}`,
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-h3)'
    }
  }, title), action), /*#__PURE__*/React.createElement("div", {
    style: {
      padding
    }
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const pascal = n => n.split('-').map(p => p[0].toUpperCase() + p.slice(1)).join('');

/** Monochrome Lucide glyph, inheriting the current text color. Requires the pinned Lucide UMD script on the page. */
function Icon({
  name,
  size = 18,
  color = 'currentColor',
  strokeWidth = 2,
  style,
  ...rest
}) {
  const [, tick] = React.useState(0);
  React.useEffect(() => {
    if (window.lucide) return undefined;
    const t = setInterval(() => {
      if (window.lucide) {
        clearInterval(t);
        tick(n => n + 1);
      }
    }, 120);
    return () => clearInterval(t);
  }, []);
  const lib = window.lucide || {};
  const key = pascal(name);
  const node = lib.icons && lib.icons[key] || lib[key] || null;
  const box = {
    display: 'inline-block',
    flex: 'none',
    width: size,
    height: size,
    ...style
  };
  if (!node) return /*#__PURE__*/React.createElement("span", _extends({
    "aria-hidden": "true"
  }, rest, {
    style: box
  }));
  // Lucide icon nodes are ["svg", attrs, children]; older shapes are a bare children array.
  const kids = Array.isArray(node) && node[0] === 'svg' ? node[2] : node;
  const children = (kids || []).map(([tag, attrs], i) => React.createElement(tag, {
    key: i,
    ...attrs
  }));
  return /*#__PURE__*/React.createElement("svg", _extends({
    "aria-hidden": "true"
  }, rest, {
    xmlns: "http://www.w3.org/2000/svg",
    viewBox: "0 0 24 24",
    width: size,
    height: size,
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: box
  }), children);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  neutral: {
    background: 'var(--white)',
    color: 'var(--etax-navy)',
    borderColor: 'var(--border-default)'
  },
  navy: {
    background: 'var(--etax-navy)',
    color: 'var(--text-inverse)',
    borderColor: 'var(--etax-navy)'
  },
  accent: {
    background: 'var(--action-accent)',
    color: 'var(--text-inverse)',
    borderColor: 'var(--action-accent)'
  },
  ghost: {
    background: 'transparent',
    color: 'var(--gray-600)',
    borderColor: 'transparent'
  }
};
const sizes = {
  sm: 32,
  md: 40,
  lg: 48
};

/** Square icon-only control: composer mic/send, playback, header actions. */
function IconButton({
  icon,
  label,
  tone = 'neutral',
  size = 'md',
  active,
  disabled,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const px = sizes[size];
  const t = tones[tone];
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    title: label,
    disabled: disabled
  }, rest, {
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: px,
      height: px,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      border: '1px solid',
      borderRadius: 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: 'background-color var(--dur-fast) var(--ease-standard),border-color var(--dur-fast) var(--ease-standard)',
      ...t,
      ...(active ? {
        background: 'var(--etax-red-100)',
        color: 'var(--etax-red-700)',
        borderColor: 'var(--etax-red)'
      } : null),
      ...(hover && !disabled && !active ? {
        background: tone === 'neutral' || tone === 'ghost' ? 'var(--gray-100)' : tone === 'navy' ? 'var(--etax-navy-800)' : 'var(--action-accent-hover)'
      } : null),
      opacity: disabled ? 0.4 : 1,
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 16 : size === 'lg' ? 22 : 18
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/chat/ChatComposer.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Message composer with microphone and send controls, plus the listening state. */
function ChatComposer({
  placeholder = 'Ask about tax data or request a tax prediction…',
  value,
  onChange,
  onSend,
  onMicToggle,
  listening,
  disabled,
  hint,
  style,
  ...rest
}) {
  const [text, setText] = React.useState('');
  const controlled = value !== undefined;
  const v = controlled ? value : text;
  const set = nv => {
    if (!controlled) setText(nv);
    onChange && onChange(nv);
  };
  const send = () => {
    if (v && v.trim() && onSend) onSend(v.trim());
    set('');
  };
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 'var(--space-2)',
      padding: 'var(--space-2)',
      background: 'var(--white)',
      border: `1px solid ${listening ? 'var(--etax-red)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-sm)',
      transition: 'border-color var(--dur-fast) var(--ease-standard)'
    }
  }, /*#__PURE__*/React.createElement("textarea", {
    rows: 1,
    value: v,
    disabled: disabled,
    placeholder: listening ? 'Listening…' : placeholder,
    onChange: e => set(e.target.value),
    onKeyDown: e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        send();
      }
    },
    style: {
      flex: 1,
      resize: 'none',
      border: 'none',
      outline: 'none',
      background: 'transparent',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-md)',
      lineHeight: 'var(--lh-normal)',
      color: 'var(--text-strong)',
      padding: 'var(--space-2) var(--space-3)',
      maxHeight: 120
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: listening ? 'square' : 'mic',
    label: listening ? 'Stop listening' : 'Speak your question',
    tone: "ghost",
    active: listening,
    onClick: onMicToggle
  }), /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "send",
    label: "Send message",
    tone: "navy",
    disabled: !v || !v.trim(),
    onClick: send
  })), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, hint));
}
Object.assign(__ds_scope, { ChatComposer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chat/ChatComposer.jsx", error: String((e && e.message) || e) }); }

// components/chat/ChatMessage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** One turn in the conversation. Assistant turns are white panels; user turns are navy-tinted blocks. */
function ChatMessage({
  role = 'assistant',
  name,
  time,
  speakable,
  playing,
  onPlay,
  children,
  style,
  ...rest
}) {
  const isUser = role === 'user';
  return /*#__PURE__*/React.createElement("article", _extends({}, rest, {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      flexDirection: isUser ? 'row-reverse' : 'row',
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 32,
      height: 32,
      flex: 'none',
      borderRadius: 'var(--radius-sm)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: isUser ? 'var(--gray-200)' : 'var(--etax-navy)',
      color: isUser ? 'var(--gray-600)' : 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: isUser ? 'user' : 'landmark',
    size: 16
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      alignItems: isUser ? 'flex-end' : 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)',
      alignItems: 'baseline'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-strong)'
    }
  }, name || (isUser ? 'You' : 'eTax Assistant')), time && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)'
    },
    className: "etax-mono"
  }, time)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-4)',
      borderRadius: 'var(--radius-md)',
      fontSize: 'var(--text-body-md)',
      lineHeight: 'var(--lh-normal)',
      color: 'var(--gray-800)',
      background: isUser ? 'var(--etax-navy-50)' : 'var(--white)',
      border: `1px solid ${isUser ? 'var(--etax-navy-100)' : 'var(--border-subtle)'}`
    }
  }, children), speakable && !isUser && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: playing ? 'pause' : 'volume-2',
    label: playing ? 'Stop playback' : 'Read this answer aloud',
    size: "sm",
    tone: "ghost",
    active: playing,
    onClick: onPlay
  }))));
}
Object.assign(__ds_scope, { ChatMessage });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/chat/ChatMessage.jsx", error: String((e && e.message) || e) }); }

// components/core/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The eTax lockup. Uses the supplied PNG mark; on navy, set inverse to add the white wordmark treatment. */
function Logo({
  height = 32,
  src = 'assets/etax-logo.png',
  inverse,
  subtitle,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "eTax",
    style: {
      height,
      width: 'auto',
      display: 'block',
      filter: inverse ? 'brightness(0) invert(1)' : undefined
    }
  }), subtitle && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 1,
      height: height * 0.62,
      background: inverse ? 'rgba(255,255,255,.32)' : 'var(--border-default)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--fw-medium)',
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: inverse ? 'rgba(255,255,255,.86)' : 'var(--gray-600)'
    }
  }, subtitle)));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Logo.jsx", error: String((e && e.message) || e) }); }

// components/data/DataTable.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Plain records table for query answers: 1px rules, tabular numerals, no zebra striping. */
function DataTable({
  columns = [],
  rows = [],
  caption,
  style,
  ...rest
}) {
  const align = c => typeof c === 'object' && c.numeric ? 'right' : 'left';
  const label = c => typeof c === 'string' ? c : c.label;
  return /*#__PURE__*/React.createElement("div", _extends({}, rest, {
    style: {
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-sm)',
      overflow: 'hidden',
      ...style
    }
  }), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 'var(--text-body-sm)'
    }
  }, caption && /*#__PURE__*/React.createElement("caption", {
    style: {
      captionSide: 'top',
      textAlign: 'left',
      padding: 'var(--space-3) var(--space-4)',
      background: 'var(--gray-25)',
      borderBottom: '1px solid var(--border-subtle)',
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, caption), /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map((c, i) => /*#__PURE__*/React.createElement("th", {
    key: i,
    style: {
      textAlign: align(c),
      padding: 'var(--space-3) var(--space-4)',
      background: 'var(--gray-50)',
      borderBottom: '1px solid var(--border-default)',
      color: 'var(--gray-600)',
      fontSize: 'var(--text-overline)',
      letterSpacing: 'var(--ls-overline)',
      textTransform: 'uppercase',
      fontWeight: 'var(--fw-semibold)'
    }
  }, label(c))))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, ri) => /*#__PURE__*/React.createElement("tr", {
    key: ri
  }, r.map((cell, ci) => /*#__PURE__*/React.createElement("td", {
    key: ci,
    style: {
      padding: 'var(--space-3) var(--space-4)',
      borderBottom: ri === rows.length - 1 ? 'none' : '1px solid var(--border-subtle)',
      textAlign: align(columns[ci]),
      color: 'var(--gray-800)',
      fontFamily: align(columns[ci]) === 'right' ? 'var(--font-mono)' : 'var(--font-body)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, cell)))))));
}
Object.assign(__ds_scope, { DataTable });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/DataTable.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  info: {
    bg: 'var(--info-100)',
    border: '#c9d7ec',
    fg: 'var(--info)',
    icon: 'info'
  },
  success: {
    bg: 'var(--success-100)',
    border: '#bfe3ce',
    fg: 'var(--success)',
    icon: 'circle-check'
  },
  warning: {
    bg: 'var(--warning-100)',
    border: '#f0d9a8',
    fg: 'var(--warning)',
    icon: 'triangle-alert'
  },
  danger: {
    bg: 'var(--danger-100)',
    border: '#f6c9c8',
    fg: 'var(--danger)',
    icon: 'circle-alert'
  }
};

/** Inline message block for form errors, security notices and verification failures. */
function Alert({
  tone = 'info',
  title,
  children,
  action,
  style,
  ...rest
}) {
  const t = tones[tone];
  return /*#__PURE__*/React.createElement("div", _extends({
    role: tone === 'danger' ? 'alert' : 'status'
  }, rest, {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      padding: 'var(--space-3) var(--space-4)',
      background: t.bg,
      border: `1px solid ${t.border}`,
      borderRadius: 'var(--radius-sm)',
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: t.icon,
    size: 18,
    color: t.fg,
    style: {
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)'
    }
  }, title && /*#__PURE__*/React.createElement("strong", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: t.fg,
      fontWeight: 'var(--fw-semibold)'
    }
  }, title), children && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--gray-700)'
    }
  }, children)), action);
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Spinner.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Determinate-looking activity indicator: a 2px navy arc. */
function Spinner({
  size = 18,
  color = 'var(--etax-navy)',
  label,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({}, rest, {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      width: size,
      height: size,
      flex: 'none',
      borderRadius: '50%',
      border: `2px solid ${color}`,
      borderTopColor: 'transparent',
      borderRightColor: 'transparent',
      animation: 'etaxSpin 700ms linear infinite'
    }
  }), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, label), /*#__PURE__*/React.createElement("style", null, '@keyframes etaxSpin{to{transform:rotate(360deg)}}'));
}
Object.assign(__ds_scope, { Spinner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Spinner.jsx", error: String((e && e.message) || e) }); }

// components/feedback/StatusSteps.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Vertical checklist of sequential security stages (camera → detection → liveness → identity). */
function StatusSteps({
  steps = [],
  current = 0,
  failed,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("ol", _extends({}, rest, {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      ...style
    }
  }), steps.map((label, i) => {
    const done = i < current;
    const active = i === current;
    const isFailed = failed && active;
    const fg = isFailed ? 'var(--danger)' : done ? 'var(--success)' : active ? 'var(--etax-navy)' : 'var(--gray-400)';
    return /*#__PURE__*/React.createElement("li", {
      key: label,
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 'var(--space-3)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 20,
        height: 20,
        flex: 'none',
        borderRadius: 'var(--radius-pill)',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        border: `1px solid ${done || isFailed ? fg : active ? 'var(--etax-navy)' : 'var(--border-default)'}`,
        background: done ? 'var(--success)' : isFailed ? 'var(--danger)' : 'var(--white)'
      }
    }, done && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "check",
      size: 12,
      color: "var(--white)"
    }), isFailed && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "x",
      size: 12,
      color: "var(--white)"
    }), active && !isFailed && /*#__PURE__*/React.createElement("span", {
      style: {
        width: 7,
        height: 7,
        borderRadius: '50%',
        background: 'var(--etax-navy)',
        animation: 'etaxPulse var(--dur-pulse) var(--ease-in-out) infinite'
      }
    })), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 'var(--text-body-sm)',
        fontWeight: active ? 'var(--fw-semibold)' : 'var(--fw-regular)',
        color: active || done ? 'var(--text-strong)' : 'var(--text-muted)'
      }
    }, label));
  }), /*#__PURE__*/React.createElement("style", null, '@keyframes etaxPulse{0%,100%{opacity:1}50%{opacity:.25}}'));
}
Object.assign(__ds_scope, { StatusSteps });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/StatusSteps.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Square checkbox with inline label — used for consent and "remember this device". */
function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  id,
  disabled,
  style,
  ...rest
}) {
  const controlled = checked !== undefined;
  const [on, setOn] = React.useState(!!defaultChecked);
  const isOn = controlled ? checked : on;
  const fid = id || `c-${label ? label.toLowerCase().replace(/[^a-z]+/g, '-').slice(0, 24) : 'check'}`;
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      display: 'inline-flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: fid,
    type: "checkbox",
    checked: isOn,
    disabled: disabled
  }, rest, {
    onChange: e => {
      if (!controlled) setOn(e.target.checked);
      onChange && onChange(e);
    },
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 18,
      height: 18,
      flex: 'none',
      marginTop: 2,
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: 'var(--radius-xs)',
      border: `1px solid ${isOn ? 'var(--etax-navy)' : 'var(--border-default)'}`,
      background: isOn ? 'var(--etax-navy)' : 'var(--white)',
      transition: 'background-color var(--dur-fast) var(--ease-standard)'
    }
  }, isOn && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check",
    size: 13,
    color: "var(--white)"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-body)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Labelled native select with the eTax chevron affordance. */
function Select({
  label,
  options = [],
  hint,
  error,
  required,
  id,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const fid = id || `s-${label ? label.toLowerCase().replace(/[^a-z]+/g, '-') : 'select'}`;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-strong)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--etax-red)'
    }
  }, " *")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("select", _extends({
    id: fid
  }, rest, {
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      width: '100%',
      height: 'var(--control-h-md)',
      padding: '0 36px 0 var(--space-3)',
      appearance: 'none',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-strong)',
      background: 'var(--white)',
      borderRadius: 'var(--radius-sm)',
      border: `1px solid ${error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)'}`,
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      outline: 'none',
      cursor: 'pointer'
    }
  }), options.map(o => {
    const value = typeof o === 'string' ? o : o.value;
    const text = typeof o === 'string' ? o : o.label;
    return /*#__PURE__*/React.createElement("option", {
      key: value,
      value: value
    }, text);
  })), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron-down",
    size: 16,
    color: "var(--gray-500)",
    style: {
      position: 'absolute',
      right: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none'
    }
  })), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: error ? 'var(--danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Labelled text input with optional hint, error and password reveal. */
function TextField({
  label,
  type = 'text',
  hint,
  error,
  required,
  id,
  revealable,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  const [shown, setShown] = React.useState(false);
  const fid = id || `f-${label ? label.toLowerCase().replace(/[^a-z]+/g, '-') : 'field'}`;
  const inputType = revealable && shown ? 'text' : type;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: fid,
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--fw-semibold)',
      color: 'var(--text-strong)'
    }
  }, label, required && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--etax-red)'
    }
  }, " *")), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: fid,
    type: inputType
  }, rest, {
    onFocus: e => {
      setFocus(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocus(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      width: '100%',
      height: 'var(--control-h-md)',
      padding: `0 ${revealable ? '40px' : 'var(--space-3)'} 0 var(--space-3)`,
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-strong)',
      background: 'var(--white)',
      borderRadius: 'var(--radius-sm)',
      border: `1px solid ${error ? 'var(--danger)' : focus ? 'var(--border-focus)' : 'var(--border-default)'}`,
      boxShadow: focus ? 'var(--focus-ring)' : 'none',
      outline: 'none',
      transition: 'border-color var(--dur-fast) var(--ease-standard),box-shadow var(--dur-fast) var(--ease-standard)'
    }
  })), revealable && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setShown(s => !s),
    "aria-label": shown ? 'Hide password' : 'Show password',
    style: {
      position: 'absolute',
      right: 0,
      top: 0,
      height: '100%',
      width: 40,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      color: 'var(--gray-500)'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: shown ? 'eye-off' : 'eye',
    size: 17
  }))), (error || hint) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: error ? 'var(--danger)' : 'var(--text-muted)',
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-1)'
    }
  }, error && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "circle-alert",
    size: 13
  }), error || hint));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/AppHeader.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Application header: logo lockup left, session state and account controls right. */
function AppHeader({
  logoSrc = 'assets/etax-logo.png',
  subtitle = 'Tax Assistant',
  user,
  verified,
  nav,
  onSignOut,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("header", _extends({}, rest, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-6)',
      height: 64,
      padding: '0 var(--space-6)',
      background: 'var(--white)',
      borderBottom: '1px solid var(--border-subtle)',
      ...style
    }
  }), /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    height: 28,
    src: logoSrc,
    subtitle: subtitle
  }), nav && /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: 'var(--space-5)',
      flex: 1
    }
  }, nav), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: nav ? 0 : 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)'
    }
  }, verified && /*#__PURE__*/React.createElement(__ds_scope.Badge, {
    tone: "success",
    style: {
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "shield-check",
    size: 12
  }), " Identity verified"), user && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      paddingLeft: 'var(--space-4)',
      borderLeft: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 28,
      height: 28,
      borderRadius: 'var(--radius-sm)',
      background: 'var(--etax-navy-50)',
      color: 'var(--etax-navy)',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--fw-semibold)'
    }
  }, user.split(' ').map(w => w[0]).slice(0, 2).join('')), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-strong)',
      whiteSpace: 'nowrap'
    }
  }, user)), onSignOut && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onSignOut,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 'var(--space-2)',
      background: 'none',
      border: 'none',
      cursor: 'pointer',
      fontFamily: 'var(--font-body)',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--gray-600)',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "log-out",
    size: 16
  }), " Sign out")));
}
Object.assign(__ds_scope, { AppHeader });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/AppHeader.jsx", error: String((e && e.message) || e) }); }

// components/overlay/Modal.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Centered dialog on a navy scrim. Used for the tax prediction form and confirmations. */
function Modal({
  open = true,
  title,
  description,
  footer,
  width = 560,
  onClose,
  children,
  style,
  ...rest
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      background: 'var(--overlay-scrim)',
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'center',
      padding: 'var(--space-12) var(--space-4)',
      overflowY: 'auto',
      zIndex: 40
    },
    onClick: e => {
      if (e.target === e.currentTarget && onClose) onClose();
    }
  }, /*#__PURE__*/React.createElement("div", _extends({
    role: "dialog",
    "aria-modal": "true",
    "aria-label": title
  }, rest, {
    style: {
      width: '100%',
      maxWidth: width,
      background: 'var(--white)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-modal)',
      ...style
    }
  }), /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 'var(--space-4)',
      padding: 'var(--space-5) var(--space-6)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-1)'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 'var(--text-h2)'
    }
  }, title), description && /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, description)), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    label: "Close",
    tone: "ghost",
    size: "sm",
    onClick: onClose
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-6)'
    }
  }, children), footer && /*#__PURE__*/React.createElement("footer", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 'var(--space-3)',
      padding: 'var(--space-4) var(--space-6)',
      borderTop: '1px solid var(--border-subtle)',
      background: 'var(--gray-25)',
      borderRadius: '0 0 var(--radius-md) var(--radius-md)'
    }
  }, footer)));
}
Object.assign(__ds_scope, { Modal });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/overlay/Modal.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tax_assistant/App.jsx
try { (() => {
function App() {
  const [screen, setScreen] = React.useState('landing');
  const [user, setUser] = React.useState('Amina Farouk');
  const go = s => setScreen(s);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100vh',
      overflow: screen === 'chat' ? 'hidden' : 'auto'
    }
  }, screen === 'landing' && /*#__PURE__*/React.createElement(window.LandingScreen, {
    onLogin: () => go('login'),
    onSignUp: () => go('signup')
  }), screen === 'signup' && /*#__PURE__*/React.createElement(window.SignUpScreen, {
    onLogin: () => go('login'),
    onSubmit: n => {
      setUser(n);
      go('verify');
    }
  }), screen === 'login' && /*#__PURE__*/React.createElement(window.LoginScreen, {
    onSignUp: () => go('signup'),
    onSubmit: n => {
      setUser(n);
      go('verify');
    }
  }), screen === 'verify' && /*#__PURE__*/React.createElement(window.FaceVerifyScreen, {
    user: user,
    onVerified: () => go('chat'),
    onCancel: () => go('login')
  }), screen === 'chat' && /*#__PURE__*/React.createElement(window.ChatScreen, {
    user: user,
    onSignOut: () => go('landing')
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tax_assistant/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tax_assistant/AuthScreens.jsx
try { (() => {
const {
  Button,
  Logo,
  Icon,
  TextField,
  Checkbox,
  Alert
} = window.ETaxDesignSystem_2776b3;
function AuthShell({
  title,
  description,
  children,
  footer
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: 'var(--surface-page)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      height: 72,
      padding: '0 var(--space-8)',
      background: 'var(--white)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 30,
    src: window.LOGO,
    subtitle: "Tax Assistant"
  })), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      padding: 'var(--space-12) var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 480
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--white)',
      border: '1px solid var(--border-subtle)',
      borderTop: '3px solid var(--action-accent)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-sm)',
      padding: 'var(--space-8)'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h1)',
      marginBottom: 'var(--space-2)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      marginBottom: 'var(--space-6)'
    }
  }, description), children), /*#__PURE__*/React.createElement("p", {
    style: {
      textAlign: 'center',
      marginTop: 'var(--space-5)',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, footer))));
}
function SignUpScreen({
  onSubmit,
  onLogin
}) {
  const [err, setErr] = React.useState('');
  const submit = e => {
    e.preventDefault();
    const f = new FormData(e.target);
    if (f.get('password') !== f.get('confirm')) {
      setErr('Passwords do not match');
      return;
    }
    onSubmit(f.get('name') || 'Amina Farouk');
  };
  return /*#__PURE__*/React.createElement(AuthShell, {
    title: "Create your account",
    description: "You will enrol your face on the next step. It is used only to confirm it is you at sign-in.",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, "Already registered? ", /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onLogin();
      }
    }, "Log in"))
  }, /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Full name",
    name: "name",
    required: true,
    placeholder: "As shown on your tax ID",
    defaultValue: "Amina Farouk"
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Email address",
    name: "email",
    type: "email",
    required: true,
    defaultValue: "a.farouk@revenue.gov",
    hint: "Used for security notices and account recovery"
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Username",
    name: "username",
    required: true,
    defaultValue: "afarouk"
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Password",
    name: "password",
    type: "password",
    revealable: true,
    required: true,
    defaultValue: "StrongPass2026",
    hint: "At least 12 characters, including a number"
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Confirm password",
    name: "confirm",
    type: "password",
    revealable: true,
    required: true,
    defaultValue: "StrongPass2026",
    error: err || undefined
  }), /*#__PURE__*/React.createElement(Checkbox, {
    defaultChecked: true,
    label: /*#__PURE__*/React.createElement(React.Fragment, null, "I agree to the ", /*#__PURE__*/React.createElement("a", {
      href: "#"
    }, "terms of use"), " and the ", /*#__PURE__*/React.createElement("a", {
      href: "#"
    }, "privacy notice"), ".")
  }), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    size: "lg",
    fullWidth: true
  }, "Create account and continue")));
}
function LoginScreen({
  onSubmit,
  onSignUp,
  initialError
}) {
  const [error, setError] = React.useState(initialError || '');
  const [pw, setPw] = React.useState('StrongPass2026');
  const submit = e => {
    e.preventDefault();
    if (pw.length < 6) {
      setError('The username or password is incorrect. Two attempts remain.');
      return;
    }
    onSubmit('Amina Farouk');
  };
  return /*#__PURE__*/React.createElement(AuthShell, {
    title: "Log in",
    description: "Face verification follows once your credentials are accepted.",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, "No account yet? ", /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onSignUp();
      }
    }, "Create one"))
  }, /*#__PURE__*/React.createElement("form", {
    onSubmit: submit,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, error && /*#__PURE__*/React.createElement(Alert, {
    tone: "danger",
    title: "Sign-in failed"
  }, error), /*#__PURE__*/React.createElement(TextField, {
    label: "Email or username",
    required: true,
    defaultValue: "afarouk",
    error: error ? ' ' : undefined
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Password",
    type: "password",
    revealable: true,
    required: true,
    value: pw,
    onChange: e => setPw(e.target.value),
    error: error ? ' ' : undefined
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Remember this device"
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 'var(--text-body-sm)'
    }
  }, "Forgot password?")), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    size: "lg",
    fullWidth: true
  }, "Log in"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)',
      display: 'flex',
      gap: 'var(--space-2)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 13
  }), " Do not share your credentials. eTax staff will never ask for your password.")));
}
Object.assign(window, {
  AuthShell,
  SignUpScreen,
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tax_assistant/AuthScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tax_assistant/ChatScreen.jsx
try { (() => {
const {
  AppHeader,
  ChatMessage,
  ChatComposer,
  SuggestionChip,
  Spinner,
  DataTable,
  Card,
  Badge,
  Button,
  Alert,
  Icon,
  IconButton
} = window.ETaxDesignSystem_2776b3;
const SUGGESTIONS = ['Show the filed returns for TIN ending 4182', 'What was the assessed income for the 2024 tax year?', 'Run a fraud risk prediction for this taxpayer'];
function PredictionResult() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("p", null, "The model returned a moderate risk score for TIN ending 4182, 2024 tax year."), /*#__PURE__*/React.createElement("div", {
    style: {
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      padding: 'var(--space-4)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 30,
      fontWeight: 500,
      color: 'var(--etax-navy)'
    }
  }, "0.58"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Badge, {
    tone: "warning"
  }, "Moderate risk"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, "Score range 0.00\u20131.00 \xB7 threshold for review 0.50"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 'var(--space-4)',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, [['Model input 1', 'Above segment median'], ['Model input 2', 'Within expected range'], ['Model input 3', 'Two amendments in period']].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 'var(--space-4)',
      fontSize: 'var(--text-body-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--gray-800)'
    }
  }, v))))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, "A score above the review threshold does not confirm fraud. Refer the case for manual review before any action."));
}
function QueryAnswer() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("p", null, "Three returns are on file for TIN ending 4182. The 2022 return was amended in November 2023."), /*#__PURE__*/React.createElement(DataTable, {
    caption: "Authorized records \xB7 TIN ending 4182",
    columns: ['Tax year', 'Return type', 'Status', {
      label: 'Assessed',
      numeric: true
    }, {
      label: 'Paid',
      numeric: true
    }],
    rows: [['2024', 'Individual', 'Filed', '412,900.00', '412,900.00'], ['2023', 'Individual', 'Filed', '388,450.00', '388,450.00'], ['2022', 'Individual', 'Amended', '341,200.00', '330,000.00']]
  }));
}
function EmptyState({
  onPick
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 700,
      margin: '0 auto',
      paddingTop: 'var(--space-16)',
      textAlign: 'left'
    }
  }, /*#__PURE__*/React.createElement("p", {
    className: "etax-overline",
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, "New conversation"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h1)',
      marginBottom: 'var(--space-3)'
    }
  }, "What would you like to look into?"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-body)',
      marginBottom: 'var(--space-6)',
      maxWidth: 560
    }
  }, "Ask about records you are authorized to access, or request a fraud risk prediction. You can type or use the microphone."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)'
    }
  }, SUGGESTIONS.map(s => /*#__PURE__*/React.createElement(SuggestionChip, {
    key: s,
    onClick: () => onPick(s)
  }, s))));
}
function ChatScreen({
  user,
  onSignOut
}) {
  const [turns, setTurns] = React.useState([]);
  const [status, setStatus] = React.useState(null); // 'retrieving' | 'predicting'
  const [listening, setListening] = React.useState(false);
  const [modal, setModal] = React.useState(false);
  const [playing, setPlaying] = React.useState(null);
  const [error, setError] = React.useState('');
  const scroller = React.useRef(null);
  React.useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [turns, status]);
  const push = t => setTurns(prev => prev.concat(t));
  const ask = text => {
    setError('');
    push({
      role: 'user',
      body: text,
      time: '09:41'
    });
    const wantsPrediction = /predict|risk|fraud/i.test(text);
    if (wantsPrediction) {
      setTimeout(() => setModal(true), 350);
      return;
    }
    setStatus('retrieving');
    setTimeout(() => {
      setStatus(null);
      push({
        role: 'assistant',
        kind: 'query',
        time: '09:41'
      });
    }, 1600);
  };
  const runPrediction = () => {
    setModal(false);
    setStatus('predicting');
    setTimeout(() => {
      setStatus(null);
      push({
        role: 'assistant',
        kind: 'prediction',
        time: '09:42'
      });
    }, 1800);
  };
  const toggleMic = () => {
    if (listening) {
      setListening(false);
      ask('What was the assessed income for the 2024 tax year?');
      return;
    }
    setListening(true);
    setTimeout(() => {
      setListening(false);
      ask('What was the assessed income for the 2024 tax year?');
    }, 2600);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement(AppHeader, {
    logoSrc: window.LOGO,
    user: user,
    verified: true,
    onSignOut: onSignOut,
    nav: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        fontSize: 'var(--text-body-sm)',
        borderBottom: '2px solid var(--etax-red)',
        paddingBottom: 2,
        color: 'var(--text-strong)',
        fontWeight: 'var(--fw-semibold)'
      }
    }, "Assistant"), /*#__PURE__*/React.createElement("a", {
      href: "#",
      style: {
        fontSize: 'var(--text-body-sm)',
        border: 'none',
        color: 'var(--gray-600)'
      }
    }, "Activity log"))
  }), /*#__PURE__*/React.createElement("div", {
    ref: scroller,
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: 'var(--space-6) var(--space-8) var(--space-8)'
    }
  }, turns.length === 0 && !status ? /*#__PURE__*/React.createElement(EmptyState, {
    onPick: ask
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 820,
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)'
    }
  }, turns.map((t, i) => /*#__PURE__*/React.createElement(ChatMessage, {
    key: i,
    role: t.role,
    time: t.time,
    speakable: t.role === 'assistant',
    playing: playing === i,
    onPlay: () => setPlaying(playing === i ? null : i)
  }, t.kind === 'query' ? /*#__PURE__*/React.createElement(QueryAnswer, null) : t.kind === 'prediction' ? /*#__PURE__*/React.createElement(PredictionResult, null) : t.body)), status && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'center',
      paddingLeft: 44
    }
  }, /*#__PURE__*/React.createElement(Spinner, {
    label: status === 'retrieving' ? 'Retrieving authorized tax data…' : 'Running the prediction model…'
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      background: 'var(--white)',
      padding: 'var(--space-4) var(--space-8) var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 820,
      margin: '0 auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, error && /*#__PURE__*/React.createElement(Alert, {
    tone: "danger",
    title: "Session expired"
  }, "Your verified session has ended. Sign in and verify again to continue."), listening && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-3)',
      padding: 'var(--space-3) var(--space-4)',
      background: 'var(--etax-red-50)',
      border: '1px solid var(--etax-red-100)',
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--etax-red)',
      animation: 'etaxPulse var(--dur-pulse) var(--ease-in-out) infinite'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--etax-red-800)',
      fontWeight: 'var(--fw-medium)'
    }
  }, "Listening \u2014 speak your question, then pause"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 3,
      alignItems: 'flex-end',
      height: 18
    }
  }, [7, 14, 10, 18, 9, 13, 6].map((h, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 3,
      height: h,
      background: 'var(--etax-red)',
      opacity: 0.8,
      animation: `etaxBar 900ms ${i * 90}ms var(--ease-in-out) infinite`
    }
  })))), /*#__PURE__*/React.createElement(ChatComposer, {
    listening: listening,
    onMicToggle: toggleMic,
    onSend: ask,
    hint: "Answers cover records you are authorized to access. Every retrieval is logged against your session."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setModal(true)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "calculator",
    size: 15
  }), " Tax prediction"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "sm",
    onClick: () => setError('x')
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-alert",
    size: 15
  }), " Show error state"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)'
    }
  }, "Session ends after 15 minutes of inactivity")))), /*#__PURE__*/React.createElement(window.PredictionModal, {
    open: modal,
    onClose: () => setModal(false),
    onRun: runPrediction
  }), /*#__PURE__*/React.createElement("style", null, '@keyframes etaxBar{0%,100%{transform:scaleY(.4)}50%{transform:scaleY(1)}}@keyframes etaxPulse{0%,100%{opacity:1}50%{opacity:.25}}'));
}
Object.assign(window, {
  ChatScreen,
  PredictionResult,
  QueryAnswer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tax_assistant/ChatScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tax_assistant/FaceVerifyScreen.jsx
try { (() => {
const {
  Button,
  Logo,
  Icon,
  StatusSteps,
  Alert,
  Badge
} = window.ETaxDesignSystem_2776b3;
const STAGES = [{
  key: 'position',
  hint: 'Position your face inside the frame',
  steps: 0
}, {
  key: 'detected',
  hint: 'Face detected — hold still',
  steps: 1
}, {
  key: 'liveness',
  hint: 'Checking liveness. Please blink once.',
  steps: 2
}, {
  key: 'identity',
  hint: 'Verifying identity against your enrolled record',
  steps: 3
}, {
  key: 'verified',
  hint: 'Identity verified',
  steps: 4
}];
function CameraFrame({
  stage,
  failed
}) {
  const live = !failed && stage !== 'verified';
  const ringColor = failed ? 'var(--danger)' : stage === 'verified' ? 'var(--success)' : stage === 'position' ? 'rgba(255,255,255,.55)' : 'var(--etax-red)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      aspectRatio: '4 / 3',
      background: 'var(--etax-navy-900)',
      borderRadius: 'var(--radius-md)',
      overflow: 'hidden',
      border: '1px solid var(--etax-navy-800)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '46%',
      height: '72%',
      border: `2px ${stage === 'position' ? 'dashed' : 'solid'} ${ringColor}`,
      borderRadius: '50% / 42%',
      transition: 'border-color var(--dur-med) var(--ease-standard)'
    }
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 12,
      left: 12,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '4px 8px',
      borderRadius: 'var(--radius-xs)',
      background: 'rgba(15,37,69,.72)',
      color: 'var(--white)',
      fontSize: 'var(--text-caption)',
      fontFamily: 'var(--font-mono)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: live ? 'var(--etax-red)' : 'var(--gray-400)',
      animation: live ? 'etaxPulse var(--dur-pulse) var(--ease-in-out) infinite' : 'none'
    }
  }), live ? 'LIVE' : 'PAUSED'), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      bottom: 12,
      left: 12,
      right: 12,
      textAlign: 'center',
      color: 'rgba(255,255,255,.62)',
      fontSize: 'var(--text-caption)'
    }
  }, "Camera preview area \u2014 replace with the live video stream"));
}
function FaceVerifyScreen({
  user,
  onVerified,
  onCancel
}) {
  const [i, setI] = React.useState(0);
  const [failed, setFailed] = React.useState(false);
  const [running, setRunning] = React.useState(true);
  React.useEffect(() => {
    if (!running || failed) return undefined;
    if (i >= STAGES.length - 1) {
      const t = setTimeout(onVerified, 1100);
      return () => clearTimeout(t);
    }
    const t = setTimeout(() => setI(n => n + 1), i === 0 ? 1400 : 1700);
    return () => clearTimeout(t);
  }, [i, running, failed]);
  const stage = STAGES[i];
  const retry = () => {
    setFailed(false);
    setI(0);
    setRunning(true);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: 'var(--surface-page)',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      height: 72,
      padding: '0 var(--space-8)',
      background: 'var(--white)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 30,
    src: window.LOGO,
    subtitle: "Identity check"
  }), /*#__PURE__*/React.createElement(Badge, {
    tone: "navy",
    style: {
      marginLeft: 'auto'
    }
  }, "Step 2 of 2")), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1,
      display: 'flex',
      justifyContent: 'center',
      padding: 'var(--space-10) var(--space-4)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 860
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-h1)',
      marginBottom: 'var(--space-2)'
    }
  }, "Verify your identity"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-body)',
      marginBottom: 'var(--space-6)'
    }
  }, user ? `${user}, ` : '', "look straight at the camera in even lighting. Nothing is recorded \u2014 the check runs and is discarded."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.4fr) minmax(0,1fr)',
      gap: 'var(--space-6)',
      background: 'var(--white)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-sm)',
      padding: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(CameraFrame, {
    stage: failed ? 'failed' : stage.key,
    failed: failed
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "etax-overline",
    style: {
      marginBottom: 'var(--space-3)'
    }
  }, "Security check"), /*#__PURE__*/React.createElement(StatusSteps, {
    steps: ['Camera ready', 'Face detected', 'Liveness check', 'Identity verified'],
    current: failed ? 2 : stage.steps,
    failed: failed
  })), failed ? /*#__PURE__*/React.createElement(Alert, {
    tone: "danger",
    title: "Verification failed"
  }, "We could not confirm your identity. Move closer, remove eyewear if possible, and try again.") : stage.key === 'verified' ? /*#__PURE__*/React.createElement(Alert, {
    tone: "success",
    title: "Identity verified"
  }, "Opening your assistant.") : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      alignItems: 'flex-start',
      padding: 'var(--space-4)',
      background: 'var(--gray-50)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-sm)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "scan-face",
    size: 18,
    color: "var(--etax-navy)",
    style: {
      marginTop: 1
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--gray-800)'
    }
  }, stage.hint)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)'
    }
  }, failed ? /*#__PURE__*/React.createElement(Button, {
    fullWidth: true,
    onClick: retry
  }, "Try again") : null, !failed && /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    fullWidth: true,
    onClick: () => {
      setFailed(true);
      setRunning(false);
    }
  }, "Simulate a failed check"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    fullWidth: true,
    onClick: onCancel
  }, "Cancel and return to login")))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-caption)',
      color: 'var(--text-muted)',
      marginTop: 'var(--space-4)',
      display: 'flex',
      gap: 'var(--space-2)',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 13
  }), " Face data stays on the verification service and is never shown to other users."))));
}
Object.assign(window, {
  FaceVerifyScreen,
  CameraFrame
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tax_assistant/FaceVerifyScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tax_assistant/LandingScreen.jsx
try { (() => {
const {
  Button,
  Logo,
  Icon,
  Card
} = window.ETaxDesignSystem_2776b3;
const LOGO = '../../assets/etax-logo.png';
function LandingHeader({
  onLogin,
  onSignUp
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      height: 72,
      padding: '0 var(--space-8)',
      background: 'var(--white)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 30,
    src: LOGO,
    subtitle: "Tax Assistant"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 'var(--space-3)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onLogin
  }, "Log in"), /*#__PURE__*/React.createElement(Button, {
    onClick: onSignUp
  }, "Create account")));
}
const CAPABILITIES = [{
  icon: 'messages-square',
  title: 'Ask in writing or by voice',
  body: 'Type a question or use the microphone. Answers can be read back aloud when you need them hands-free.'
}, {
  icon: 'shield-alert',
  title: 'Fraud risk assessment',
  body: 'Run the assessment model on a taxpayer record and see the predicted risk level with the factors behind it.'
}, {
  icon: 'database',
  title: 'Authorized data only',
  body: 'Queries are limited to the records your account is cleared to see. Every retrieval is logged against your session.'
}];
function LandingScreen({
  onLogin,
  onSignUp
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      background: 'var(--surface-page)'
    }
  }, /*#__PURE__*/React.createElement(LandingHeader, {
    onLogin: onLogin,
    onSignUp: onSignUp
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      maxWidth: 'var(--container-lg)',
      margin: '0 auto',
      padding: 'var(--space-16) var(--space-8) var(--space-12)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'minmax(0,1.15fr) minmax(0,.85fr)',
      gap: 'var(--space-16)',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    className: "etax-overline",
    style: {
      marginBottom: 'var(--space-4)'
    }
  }, "Revenue service \xB7 secure portal"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 'var(--text-display-lg)',
      letterSpacing: 'var(--ls-display)',
      lineHeight: 'var(--lh-tight)',
      marginBottom: 'var(--space-5)'
    }
  }, "A tax assistant for authorized enquiries and risk assessment"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-lg)',
      color: 'var(--text-body)',
      maxWidth: 560,
      marginBottom: 'var(--space-8)',
      textWrap: 'pretty'
    }
  }, "eTax answers questions about taxpayer records you are cleared to access and runs the fraud risk model on request. Access requires an account and face verification at every sign-in."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 'var(--space-3)',
      marginBottom: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "accent",
    size: "lg",
    onClick: onSignUp
  }, "Create account"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: onLogin
  }, "Log in")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)',
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-2)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock",
    size: 14
  }), " Sessions are encrypted and expire after 15 minutes of inactivity.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)'
    }
  }, CAPABILITIES.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.title,
    style: {
      display: 'flex',
      gap: 'var(--space-4)',
      padding: 'var(--space-5)',
      background: 'var(--white)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: c.icon,
    size: 20,
    color: "var(--etax-navy)",
    style: {
      marginTop: 2
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 'var(--text-body-md)',
      marginBottom: 'var(--space-1)'
    }
  }, c.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-body)'
    }
  }, c.body))))))), /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: '1px solid var(--border-subtle)',
      background: 'var(--white)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 'var(--container-lg)',
      margin: '0 auto',
      padding: 'var(--space-6) var(--space-8)',
      display: 'flex',
      flexWrap: 'wrap',
      gap: 'var(--space-6)',
      alignItems: 'center',
      fontSize: 'var(--text-body-sm)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Logo, {
    height: 22,
    src: LOGO
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 'var(--space-6)'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Privacy notice"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Terms of use"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Report a problem")))));
}
Object.assign(window, {
  LandingScreen,
  LandingHeader,
  LOGO
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tax_assistant/LandingScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/tax_assistant/PredictionModal.jsx
try { (() => {
const {
  Modal,
  Button,
  TextField,
  Select,
  Alert
} = window.ETaxDesignSystem_2776b3;

/** Prediction inputs. Field names are deliberate placeholders — swap in the trained model's variables. */
function PredictionModal({
  open,
  onClose,
  onRun
}) {
  return /*#__PURE__*/React.createElement(Modal, {
    open: open,
    onClose: onClose,
    width: 640,
    title: "Tax prediction inputs",
    description: "Values are used for this prediction only and are not written to the taxpayer record.",
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      onClick: onClose
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      onClick: onRun
    }, "Run prediction"))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    title: "Placeholder inputs"
  }, "Replace these five fields with the trained model's variables before release."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 'var(--space-4) var(--space-5)'
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Taxpayer reference",
    required: true,
    defaultValue: "TIN-\u2022\u2022\u2022\u2022 4182",
    hint: "Must be a record you are authorized to access"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Assessment period",
    required: true,
    options: ['2024 tax year', '2023 tax year', '2022 tax year']
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Model input 1",
    placeholder: "Numeric placeholder",
    required: true
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Model input 2",
    placeholder: "Numeric placeholder",
    required: true
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Model input 3",
    placeholder: "Numeric placeholder"
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Model input 4",
    options: ['Category A', 'Category B', 'Category C']
  }))));
}
Object.assign(window, {
  PredictionModal
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/tax_assistant/PredictionModal.jsx", error: String((e && e.message) || e) }); }

__ds_ns.ChatComposer = __ds_scope.ChatComposer;

__ds_ns.ChatMessage = __ds_scope.ChatMessage;

__ds_ns.SuggestionChip = __ds_scope.SuggestionChip;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.DataTable = __ds_scope.DataTable;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Spinner = __ds_scope.Spinner;

__ds_ns.StatusSteps = __ds_scope.StatusSteps;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.AppHeader = __ds_scope.AppHeader;

__ds_ns.Modal = __ds_scope.Modal;

})();
