Renders retrieved tax records inside an assistant answer.

```jsx
<DataTable caption="Authorized records · TIN ending 4182"
  columns={["Tax year", "Return type", { label: "Assessed", numeric: true }]}
  rows={[["2024", "Individual", "412,900.00"]]} />
```

No zebra stripes, no sorting chrome. Amounts right-aligned in IBM Plex Mono with tabular numerals. Keep answers to the columns the user asked about.
