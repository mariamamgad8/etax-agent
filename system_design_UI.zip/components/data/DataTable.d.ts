export interface DataTableColumn { label: string; numeric?: boolean }
export interface DataTableProps {
  /** Column labels, or {label, numeric} — numeric columns are right-aligned and set in mono. */
  columns: Array<string | DataTableColumn>;
  /** Row cells as arrays of strings/nodes, in column order. */
  rows: Array<Array<React.ReactNode>>;
  /** Small line above the table naming the source scope, e.g. "Authorized records · TIN ending 4182". */
  caption?: string;
  style?: React.CSSProperties;
}
export declare function DataTable(props: DataTableProps): JSX.Element;
