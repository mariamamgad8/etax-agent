export interface BadgeProps {
  tone?: 'neutral' | 'navy' | 'success' | 'warning' | 'danger';
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Badge(props: BadgeProps): JSX.Element;
