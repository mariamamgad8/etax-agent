export interface IconProps {
  /** Lucide icon name in kebab-case, e.g. "mic", "send", "shield-check". */
  name: string;
  /** Pixel box for the glyph. Default 18. */
  size?: number;
  /** Any CSS color; defaults to currentColor. */
  color?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
