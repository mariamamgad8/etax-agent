The eTax lockup, optionally with a product qualifier divided by a 1px rule.

```jsx
<Logo height={32} src="../../assets/etax-logo.png" subtitle="Tax Assistant" />
```

Clear space = half the mark height on all sides. Never recolor, outline, or rebuild the mark; on navy use `inverse` (solid white knockout) rather than the red/navy original.
