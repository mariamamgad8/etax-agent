export interface LogoProps {
  /** Mark height in px. Minimum 24; header default 32. */
  height?: number;
  /** Path to the logo asset, relative to the consuming page. */
  src?: string;
  /** Knock the mark out to solid white for navy backgrounds. */
  inverse?: boolean;
  /** Product qualifier set beside the mark, e.g. "Tax Assistant". */
  subtitle?: string;
  style?: React.CSSProperties;
}
export declare function Logo(props: LogoProps): JSX.Element;
