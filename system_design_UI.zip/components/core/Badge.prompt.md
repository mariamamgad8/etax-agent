Compact status label for record states and risk levels.

```jsx
<Badge tone="danger">High risk</Badge>
<Badge tone="navy">Verified session</Badge>
```

Sentence case, 2–3 words max. 2px radius — do not make badges pill-shaped.
