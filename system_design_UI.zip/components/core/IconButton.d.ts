export interface IconButtonProps {
  /** Lucide icon name. */
  icon: string;
  /** Required accessible label — icon-only controls always carry one. */
  label: string;
  tone?: 'neutral' | 'navy' | 'accent' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  /** Recording / playing state — renders the red active treatment. */
  active?: boolean;
  disabled?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  style?: React.CSSProperties;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
