Monochrome Lucide glyph that inherits the current text color (the page must load the pinned Lucide UMD script) — use for every icon in eTax UI; never inline hand-drawn SVG or emoji.

```jsx
<Icon name="shield-check" size={20} color="var(--etax-red)" />
```

Names are Lucide kebab-case (`mic`, `mic-off`, `send`, `volume-2`, `log-out`, `user`, `scan-face`, `lock`, `eye`, `eye-off`, `check`, `circle-alert`, `chevron-down`, `database`, `calculator`). Sizes in use: 16 (inline/labels), 18 (buttons), 20–22 (headers), 28+ (state illustrations).
