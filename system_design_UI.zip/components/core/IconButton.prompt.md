Icon-only square control for composer, playback and header actions.

```jsx
<IconButton icon="mic" label="Speak your question" active={listening} />
<IconButton icon="send" label="Send" tone="navy" />
```

`active` is the red recording/playing state (used by mic and speaker). Same 4px radius and heights as Button.
