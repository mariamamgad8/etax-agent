export interface ButtonProps {
  /** primary (navy) is the default commit action; accent (eTax red) is reserved for one action per screen. */
  variant?: 'primary' | 'accent' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  fullWidth?: boolean;
  disabled?: boolean;
  /** Render as another tag, e.g. "a" for link-styled actions. */
  as?: 'button' | 'a';
  onClick?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
