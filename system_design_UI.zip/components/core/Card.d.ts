export interface CardProps {
  /** Optional header title; omit for a plain panel. */
  title?: string;
  /** Right-aligned header slot (link or small button). */
  action?: React.ReactNode;
  /** Body padding token. Default var(--space-6). */
  padding?: string;
  /** 3px eTax red top rule — use sparingly, for the single primary panel on a screen. */
  accentTop?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Card(props: CardProps): JSX.Element;
