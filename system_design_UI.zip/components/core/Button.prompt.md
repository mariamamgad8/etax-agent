The standard eTax text action — 4px radius, semibold label, no gradients or elevation.

```jsx
<Button variant="primary" size="lg" fullWidth>Continue to verification</Button>
<Button variant="secondary"><Icon name="log-out" size={16} /> Sign out</Button>
```

Variants: `primary` navy (default), `accent` eTax red (max one per screen — e.g. "Get started"), `secondary` white with gray border, `ghost` navy text, `danger` white with red border. Sizes 32 / 40 / 48px.
