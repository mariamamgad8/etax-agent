Flat white content panel — the only container shape in the system (6px radius, 1px `--border-subtle`, `--shadow-sm`).

```jsx
<Card title="Prediction result" accentTop>…</Card>
```

Never stack cards inside cards; never round more than 6px. `accentTop` marks the one lead panel per screen.
