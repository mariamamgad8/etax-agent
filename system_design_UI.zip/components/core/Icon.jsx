import React from 'react';

const pascal = (n) => n.split('-').map((p) => p[0].toUpperCase() + p.slice(1)).join('');

/** Monochrome Lucide glyph, inheriting the current text color. Requires the pinned Lucide UMD script on the page. */
export function Icon({ name, size = 18, color = 'currentColor', strokeWidth = 2, style, ...rest }) {
  const [, tick] = React.useState(0);
  React.useEffect(() => {
    if (window.lucide) return undefined;
    const t = setInterval(() => { if (window.lucide) { clearInterval(t); tick((n) => n + 1); } }, 120);
    return () => clearInterval(t);
  }, []);
  const lib = window.lucide || {};
  const key = pascal(name);
  const node = (lib.icons && lib.icons[key]) || lib[key] || null;
  const box = { display: 'inline-block', flex: 'none', width: size, height: size, ...style };
  if (!node) return <span aria-hidden="true" {...rest} style={box} />;
  // Lucide icon nodes are ["svg", attrs, children]; older shapes are a bare children array.
  const kids = Array.isArray(node) && node[0] === 'svg' ? node[2] : node;
  const children = (kids || []).map(([tag, attrs], i) => React.createElement(tag, { key: i, ...attrs }));
  return (
    <svg
      aria-hidden="true" {...rest} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"
      width={size} height={size} fill="none" stroke={color} strokeWidth={strokeWidth}
      strokeLinecap="round" strokeLinejoin="round" style={box}
    >
      {children}
    </svg>
  );
}
