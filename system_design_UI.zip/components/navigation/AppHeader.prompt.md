The 64px application header used on every signed-in screen.

```jsx
<AppHeader logoSrc="../../assets/etax-logo.png" user="Amina Farouk" verified onSignOut={signOut} />
```

Always white with a 1px bottom border — never navy, never sticky-translucent. The verified badge only appears after face verification succeeds in the current session.
