export interface AppHeaderProps {
  /** Path to the eTax mark, relative to the page. */
  logoSrc?: string;
  /** Product qualifier beside the mark. Default "Tax Assistant". */
  subtitle?: string;
  /** Signed-in user's full name; initials are derived. */
  user?: string;
  /** Show the "Identity verified" session badge. */
  verified?: boolean;
  /** Optional nav links. */
  nav?: React.ReactNode;
  onSignOut?: () => void;
  style?: React.CSSProperties;
}
export declare function AppHeader(props: AppHeaderProps): JSX.Element;
