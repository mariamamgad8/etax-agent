Starter question on the empty conversation state. Rectangular (4px), white, navy hover — never pill-shaped or gradient-filled.

```jsx
<SuggestionChip onClick={() => ask(q)}>Show my filed returns for the last three years</SuggestionChip>
```

Show 3 at most, phrased as real user requests in sentence case.
