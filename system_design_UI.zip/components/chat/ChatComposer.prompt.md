The assistant's input row: textarea + mic + send. Enter sends, Shift+Enter adds a line.

```jsx
<ChatComposer listening={listening} onMicToggle={toggle} onSend={ask}
  hint="Answers cover records you are authorized to access." />
```

In the listening state the border turns eTax red, the placeholder becomes "Listening…", and the mic becomes a stop square.
