export interface ChatComposerProps {
  placeholder?: string;
  value?: string;
  onChange?: (value: string) => void;
  onSend?: (value: string) => void;
  onMicToggle?: () => void;
  /** Voice input active — border turns red and the mic becomes a stop control. */
  listening?: boolean;
  disabled?: boolean;
  /** Small line under the composer, e.g. the data-scope disclaimer. */
  hint?: string;
  style?: React.CSSProperties;
}
export declare function ChatComposer(props: ChatComposerProps): JSX.Element;
