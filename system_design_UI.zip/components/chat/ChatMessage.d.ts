export interface ChatMessageProps {
  role?: 'assistant' | 'user';
  /** Speaker name; defaults to "eTax Assistant" / "You". */
  name?: string;
  /** Timestamp string, rendered in mono. */
  time?: string;
  /** Show the read-aloud control (assistant turns only). */
  speakable?: boolean;
  /** Playback in progress — control turns red. */
  playing?: boolean;
  onPlay?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function ChatMessage(props: ChatMessageProps): JSX.Element;
