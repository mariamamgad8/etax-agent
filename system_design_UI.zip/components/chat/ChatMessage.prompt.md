A single conversation turn. Assistant answers may contain plain paragraphs, DataTable results, or a prediction summary Card.

```jsx
<ChatMessage role="user" time="09:41">What was my assessed income in 2024?</ChatMessage>
<ChatMessage speakable time="09:41">Your assessed income for 2024 was …</ChatMessage>
```

Assistant = white panel, user = navy-tinted panel, both 6px radius with a 32px square avatar. Max text column 640px.
