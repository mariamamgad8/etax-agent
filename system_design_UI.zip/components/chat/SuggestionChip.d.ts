export interface SuggestionChipProps {
  children?: React.ReactNode;
  onClick?: () => void;
  style?: React.CSSProperties;
}
export declare function SuggestionChip(props: SuggestionChipProps): JSX.Element;
