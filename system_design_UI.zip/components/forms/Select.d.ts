export interface SelectOption { value: string; label: string }
export interface SelectProps {
  label?: string;
  /** Strings or {value,label} pairs. */
  options?: Array<string | SelectOption>;
  hint?: string;
  error?: string;
  required?: boolean;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  id?: string;
  style?: React.CSSProperties;
}
export declare function Select(props: SelectProps): JSX.Element;
