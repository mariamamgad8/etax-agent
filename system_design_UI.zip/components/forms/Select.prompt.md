Native select styled to match TextField — same height, border and focus ring.

```jsx
<Select label="Filing status" options={["Individual", "Sole trader", "Company"]} required />
```
