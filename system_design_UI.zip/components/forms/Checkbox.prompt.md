Consent and preference checkbox — 18px square, navy fill when checked.

```jsx
<Checkbox label="I agree to the terms of use and privacy notice" />
```

Label may contain links. There is no switch/toggle in this system; use Checkbox for binary settings.
