export interface TextFieldProps {
  label?: string;
  type?: 'text' | 'email' | 'password' | 'number' | 'tel' | 'date';
  placeholder?: string;
  /** Helper text under the field; hidden when error is set. */
  hint?: string;
  /** Error message — turns the border red and prefixes an alert glyph. */
  error?: string;
  required?: boolean;
  /** Adds the show/hide eye control (password fields). */
  revealable?: boolean;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  id?: string;
  style?: React.CSSProperties;
}
export declare function TextField(props: TextFieldProps): JSX.Element;
