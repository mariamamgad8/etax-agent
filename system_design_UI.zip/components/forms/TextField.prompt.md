The single text input used across sign-up, login and prediction forms.

```jsx
<TextField label="Email address" type="email" required placeholder="name@domain.gov" />
<TextField label="Password" type="password" revealable hint="At least 12 characters" />
```

Labels are sentence case and always visible — no placeholder-only fields. Required fields carry a red asterisk. 40px tall, 4px radius, navy focus ring.
