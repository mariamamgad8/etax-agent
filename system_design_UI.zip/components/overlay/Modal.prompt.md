Dialog for structured input the conversation can't carry — chiefly the tax prediction form.

```jsx
<Modal title="Tax prediction inputs" description="Values are used for this prediction only."
  footer={<><Button variant="secondary" onClick={close}>Cancel</Button><Button onClick={run}>Run prediction</Button></>}>
  …fields…
</Modal>
```

Scrim is navy at 42%. Never nest modals; never use one for a message that could be an Alert.
