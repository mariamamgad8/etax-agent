export interface ModalProps {
  open?: boolean;
  title?: string;
  /** One-line explanation under the title. */
  description?: string;
  /** Action row, right-aligned on a light gray footer. */
  footer?: React.ReactNode;
  /** Max width in px. 560 default; 720 for two-column forms. */
  width?: number;
  onClose?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Modal(props: ModalProps): JSX.Element;
