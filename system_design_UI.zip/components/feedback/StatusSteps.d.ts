export interface StatusStepsProps {
  /** Ordered stage labels, e.g. ["Camera ready","Face detected","Liveness check","Identity verified"]. */
  steps: string[];
  /** Index of the in-progress stage; everything before it renders complete. */
  current?: number;
  /** Marks the current stage as failed (red cross). */
  failed?: boolean;
  style?: React.CSSProperties;
}
export declare function StatusSteps(props: StatusStepsProps): JSX.Element;
