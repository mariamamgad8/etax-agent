Inline notice for authentication errors, verification failures and security messages. There is no toast in this system — messages stay in place next to what caused them.

```jsx
<Alert tone="danger" title="Verification failed">
  We could not confirm your identity. Check your lighting and try again.
</Alert>
```
