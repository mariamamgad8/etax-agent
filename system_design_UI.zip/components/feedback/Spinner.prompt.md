Activity arc paired with a plain status sentence.

```jsx
<Spinner label="Retrieving authorized tax data…" />
```

Status copy states what the system is doing in user terms — never mention SQL, agents, models or endpoints.
