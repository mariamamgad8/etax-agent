export interface SpinnerProps {
  size?: number;
  color?: string;
  /** Optional status text, e.g. "Retrieving authorized tax data…". */
  label?: string;
  style?: React.CSSProperties;
}
export declare function Spinner(props: SpinnerProps): JSX.Element;
