export interface AlertProps {
  tone?: 'info' | 'success' | 'warning' | 'danger';
  title?: string;
  /** Body copy — one or two plain sentences telling the user what to do next. */
  children?: React.ReactNode;
  /** Optional trailing action (small button or link). */
  action?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Alert(props: AlertProps): JSX.Element;
