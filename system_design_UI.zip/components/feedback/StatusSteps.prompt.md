Sequential security-stage checklist — built for the face verification flow, reusable for any multi-stage check.

```jsx
<StatusSteps steps={["Camera ready", "Face detected", "Liveness check", "Identity verified"]} current={2} />
```

Completed stages get a green check, the active stage a pulsing navy dot, a failure a red cross. Labels are short status statements, never instructions.
